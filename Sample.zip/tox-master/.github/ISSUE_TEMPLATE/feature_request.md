---
name: Feature request
about: Suggest an improvement for the project
title: ""
labels: feature:new
assignees: ''

---

Describe what improvement you want and how would this be used. Thanks!
