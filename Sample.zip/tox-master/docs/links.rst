.. _`Cookiecutter`: https://cookiecutter.readthedocs.io
.. _`pluggy`: https://pluggy.readthedocs.io
.. _`cookiecutter-tox-plugin`: https://github.com/tox-dev/cookiecutter-tox-plugin
.. _devpi: https://doc.devpi.net
.. _Python: https://www.python.org
.. _virtualenv: https://pypi.org/project/virtualenv
.. _`pytest`: https://pytest.org
.. _nosetests:
.. _`nose`: https://pypi.org/project/nose
.. _`Holger Krekel`: https://twitter.com/hpk42
.. _`pytest-xdist`: https://pypi.org/project/pytest-xdist
.. _ConfigParser: https://docs.python.org/3/library/configparser.html

.. _`easy_install`: http://peak.telecommunity.com/DevCenter/EasyInstall
.. _pip: https://pypi.org/project/pip
.. _setuptools: https://pypi.org/project/setuptools
.. _`jenkins`: https://jenkins.io/index.html
.. _sphinx: https://pypi.org/project/Sphinx
.. _discover: https://pypi.org/project/discover
.. _unittest2: https://pypi.org/project/unittest2
.. _mock: https://pypi.org/project/mock/
.. _flit: https://flit.readthedocs.io/en/latest/
.. _poetry: https://poetry.eustace.io/
.. _pypy: https://pypy.org

.. _`Python Packaging Guide`: https://packaging.python.org/tutorials/packaging-projects/
.. _`tox.ini`: :doc:configfile

.. _`PEP-508`: https://www.python.org/dev/peps/pep-0508/
.. _`PEP-517`: https://www.python.org/dev/peps/pep-0517/
.. _`PEP-518`: https://www.python.org/dev/peps/pep-0518/
